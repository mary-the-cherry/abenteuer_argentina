# Abenteuer Argentina - Der Online Reiseführer über Argentinien

### About

Homepage about Buenos Aires and Patagonia, Food in Argentina, Culture

Language: German

### Release 

- First Git Release after move from Bitbucket to Github


### Architecture

- Classic Approch: Use of CSS/HTML/JS

### Used foreign Libs

- Bootstrag 4.5
- JQuery
- Popper
- CookieConsent from Osano

### Owner

Maren Meyer

### Releases

#### Release 2.0:

Funcionalities:

- New Cookie Tool: Use of Cookie Consent Tool from Osano
- Add of a favicon
- Possibility of see photos in a bigger size

Content: 
- New Page about Iguazu
- Update Index Page about up-to-date Covid situation in Argentina 

